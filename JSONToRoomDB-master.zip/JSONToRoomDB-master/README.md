# JSONToRoomDB
A sample Android application to show how to get JSON response from the server and store it to Room Database
