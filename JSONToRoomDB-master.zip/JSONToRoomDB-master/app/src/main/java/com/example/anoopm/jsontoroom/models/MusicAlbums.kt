package com.example.anoopm.jsontoroom.models

// data class for music
data class MusicAlbums(val title:String, val artist:String, val url:String, val image:String, val thumbnail_image: String)
