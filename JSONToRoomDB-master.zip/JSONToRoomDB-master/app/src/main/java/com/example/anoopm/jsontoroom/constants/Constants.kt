package com.example.anoopm.jsontoroom.constants


class Constants {

    companion object {
        const val baseURL = "https://rallycoding.herokuapp.com"
    }
}