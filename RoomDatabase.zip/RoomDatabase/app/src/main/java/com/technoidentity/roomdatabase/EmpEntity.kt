package com.technoidentity.roomdatabase

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class EmpEntity (

    @PrimaryKey
    var empId: Int = 0,

    @ColumnInfo(name = "EMP_NAME")
    var empName: String? = null,

    @ColumnInfo(name = "EMP_POST")
    var empPost: String? = null
)
