package com.technoidentity.roomdatabase.customers

class CustomersRequest {
}