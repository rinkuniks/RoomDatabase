package com.technoidentity.roomdatabase

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.technoidentity.roomdatabase.customers.CustomerModel

@Dao
interface EmpDAO
{
    @Insert
    fun insert(arrayList : ArrayList<CustomerModel>)

    @Delete
    fun delete (items : CustomerModel)

    @Query("SELECT * FROM customerListDb ")
    fun fetchAll(): ArrayList<CustomerModel>
}
