package com.technoidentity.roomdatabase

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.technoidentity.roomdatabase.customers.CustomerModel
import com.technoidentity.roomdatabase.customers.CustomersResponse
import com.technoidentity.roomdatabase.retrofit.MpiSource
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.activityUiThread
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.longToast
import retrofit2.Call
import retrofit2.Response
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {

    private var dataBase: AppDB? = null
    private lateinit var recyclerView : RecyclerView
    private lateinit var myAdapter : AddressAdapter
    private var arrayList = ArrayList<CustomerModel>()
    private val TAG = MainActivity::class.java.simpleName
    private var progress: ProgressDialog? = null
    private var source = MpiSource()
    private var response = ArrayList<CustomerModel>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        databaseInitialize()

        getServiceCall(0,100)
//        val dataBase = Room.databaseBuilder(this,AppDB::class.java,"EmployeeDB").build()

//        Thread{
//            val empEntity = EmpEntity()
//            empEntity.empId = 1
//            empEntity.empName = "Nikhil Singh kumar"
//            empEntity.empPost = "Developer"
//
//            dataBase?.empDAO()?.saveEmp(empEntity)
//
//            dataBase?.empDAO()?.readEmp()?.forEach {
//                Log.v("DATABASE===", " ${it.empId} ")
//                Log.v("DATABASE===","${it.empName} ")
//                Log.v("DATABASE==="," ${it.empPost} ")
//            }
//        }.start()


    }

    private fun getServiceCall(i: Int, i1: Int) {
        showLoadingDialog()
        if (Constants.haveInternet(this)) {
            source.getRestApi(this)!!.getCustomerDetails(i, i1)
                .enqueue(object : retrofit2.Callback<CustomersResponse> {
                    override fun onResponse(call: Call<CustomersResponse>, response: Response<CustomersResponse>) {
                        Log.d("", "onResponse : CustomersAll $response")
                        if (response.code() == 200) {
                            getCustomerListResponse(Objects.requireNonNull<CustomersResponse>(response.body()))
                            dismissLoadingDialog()
                        } else {
                            Toast.makeText(this@MainActivity, "No List Found", Toast.LENGTH_LONG).show()
                            dismissLoadingDialog()
                        }
                    }

                    override fun onFailure(call: Call<CustomersResponse>, t: Throwable) {
                        Log.d(TAG, "onResponse : CustomerFailure")
                        t.printStackTrace()
                        dismissLoadingDialog()
                    }
                })
        } else {
            dismissLoadingDialog()
            Constants.InternetSettings(this)
        }
    }

    private fun getCustomerListResponse(body: CustomersResponse?) {
        response = body!!.customerList
        if (body.customerList.size > 0) {
            arrayList.clear()
            arrayList.addAll(body.customerList)
            saveData(response)
        } else {
            return
        }
    }

    private fun saveData(response: ArrayList<CustomerModel>) {
        doAsync {
            val currentDBPath = getDatabasePath("app_database").absolutePath
            println("DBPath is $currentDBPath")

            val items = ArrayList<CustomerModel>()
            for (elements in response) {
                val item = CustomerModel()
                item.name = elements.name
                item.address = elements.address
                items.add(item)
            }
            dataBase?.empDAO()?.insert(items)

            val musicAlbums = dataBase?.empDAO()?.fetchAll()
            activityUiThread {
                longToast("Data Got saved")
                refreshUIWith(musicAlbums!!)
            }
        }
    }

    private fun refreshUIWith(musicAlbums: ArrayList<CustomerModel>) {
        recyclerView = recyclerView_customer
        recyclerView.layoutManager = LinearLayoutManager(this)
        myAdapter = AddressAdapter(this, musicAlbums)
        recyclerView.adapter = myAdapter
        myAdapter.notifyDataSetChanged()
    }

    private fun showLoadingDialog() {
        if (progress == null) {
            progress = ProgressDialog(this)
            progress?.setTitle("MPI")
            progress?.setMessage("Loading......")
        }
        progress?.show()
        progress?.setCancelable(false)
    }

    private fun dismissLoadingDialog() {
        if (progress != null && progress!!.isShowing) {
            progress?.dismiss()
        }
    }

    private fun databaseInitialize() {
        dataBase = AppDB.getDatabase(applicationContext)
    }
}
